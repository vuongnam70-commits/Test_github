export type Scene={start:number;end:number;narration:string;caption:string;visual_prompt:string};
export type VideoScript={title:string;duration:number;scenes:Scene[];cta:string};
export interface AIProvider { generateScript(input:{prompt:string;template:string;duration:number}):Promise<VideoScript>; }
