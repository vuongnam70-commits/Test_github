import {mockAI} from './mock';
export function getAIProvider(){ return mockAI; }
