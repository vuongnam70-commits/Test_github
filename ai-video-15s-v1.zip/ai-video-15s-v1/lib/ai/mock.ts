import {AIProvider,VideoScript} from './types';

export const mockAI:AIProvider={async generateScript({prompt,duration}){
 const d=duration===20?5:duration===10?3:4; const sceneDur=Math.floor(duration/d); const scenes=Array.from({length:d},(_,i)=>({start:i*sceneDur,end:i===d-1?duration:(i+1)*sceneDur,narration:i===0?prompt:`Nội dung cảnh ${i}: ${prompt}`,caption:i===0?prompt:`Điểm nổi bật ${i}`,visual_prompt:`vertical social video visual about ${prompt}, modern, clean, high contrast` })); return {title:prompt.slice(0,80),duration,scenes,cta:'Follow để xem thêm!'};
}};
