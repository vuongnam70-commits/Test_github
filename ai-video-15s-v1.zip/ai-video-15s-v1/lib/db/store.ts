import {VideoScript} from '@/lib/ai/types';

type Video={id:string;prompt:string;template:string;duration:number;status:string;stage?:string;script?:VideoScript;video_url?:string;error_message?:string};
const globalStore=globalThis as unknown as {__videos?:Map<string,Video>};
export const videos=globalStore.__videos ??= new Map();
