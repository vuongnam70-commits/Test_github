import {videos} from '@/lib/db/store';
import {getAIProvider} from '@/lib/ai';

export async function processVideo(id:string){
 const v=videos.get(id); if(!v)return;
 try{v.status='generating_script';v.stage='Đang viết kịch bản';
 const script=await getAIProvider().generateScript({prompt:v.prompt,template:v.template,duration:v.duration});v.script=script;
 v.status='completed';v.stage='Video demo đã sẵn sàng';
 // V1 scaffold: replace this URL with the rendered Remotion/S3/Supabase asset in production.
 v.video_url='/demo-video.mp4';
 }catch(e){v.status='failed';v.error_message=e instanceof Error?e.message:'Unknown error';}
}
