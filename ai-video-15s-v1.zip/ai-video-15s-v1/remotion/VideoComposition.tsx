import React from 'react';
import {AbsoluteFill,Audio,Img,Sequence,useCurrentFrame,useVideoConfig} from 'remotion';
import {VideoScript} from '@/lib/ai/types';

export const VideoComposition=({script}:{script:VideoScript})=>{const frame=useCurrentFrame();const {fps}=useVideoConfig();const seconds=frame/fps;const scene=script.scenes.find(s=>seconds>=s.start&&seconds<s.end)||script.scenes[script.scenes.length-1];return <AbsoluteFill style={{background:'#111',color:'#fff',fontFamily:'Arial',justifyContent:'center',alignItems:'center',padding:60,textAlign:'center'}}><div style={{fontSize:62,fontWeight:800,lineHeight:1.05}}>{scene?.caption}</div><div style={{position:'absolute',bottom:100,fontSize:32,opacity:.9}}>{script.cta}</div></AbsoluteFill>}
