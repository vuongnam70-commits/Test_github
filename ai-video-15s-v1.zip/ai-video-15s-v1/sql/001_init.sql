create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text,
 avatar_url text,
 plan text not null default 'free',
 credits integer not null default 3,
 created_at timestamptz not null default now()
);

create table if not exists public.templates (
 id text primary key,
 name text not null,
 slug text unique not null,
 description text,
 config_json jsonb not null default '{}'::jsonb,
 is_active boolean not null default true,
 is_premium boolean not null default false,
 created_at timestamptz not null default now()
);

create table if not exists public.videos (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 title text,
 prompt text not null,
 template_id text references public.templates(id),
 duration integer not null check(duration in (10,15,20)),
 aspect_ratio text not null default '9:16',
 resolution text not null default '720x1280',
 status text not null default 'queued',
 script_json jsonb,
 settings_json jsonb not null default '{}'::jsonb,
 thumbnail_url text,
 video_url text,
 error_message text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.video_assets (
 id uuid primary key default gen_random_uuid(),
 video_id uuid not null references public.videos(id) on delete cascade,
 type text not null,
 provider text,
 storage_path text,
 metadata_json jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);

create table if not exists public.credit_transactions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 type text not null,
 amount integer not null,
 reference_id text,
 description text,
 created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.video_assets enable row level security;
alter table public.credit_transactions enable row level security;

create policy "profiles own" on public.profiles for all using (auth.uid()=id) with check (auth.uid()=id);
create policy "videos own" on public.videos for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "assets own" on public.video_assets for all using (exists(select 1 from public.videos v where v.id=video_id and v.user_id=auth.uid()));
create policy "credits own read" on public.credit_transactions for select using (auth.uid()=user_id);

insert into public.templates(id,name,slug,description) values
('viral','🔥 Viral','viral','Hook → vấn đề → giải pháp → CTA'),
('top-list','📋 Top List','top-list','Hook → danh sách → CTA'),
('product','🛍️ Product','product','Hook → sản phẩm → lợi ích → CTA'),
('story','🎬 Story','story','Hook → tình huống → kết'),
('quote','✨ Quote','quote','Câu nói → hình ảnh → CTA')
on conflict(id) do nothing;
