# AI Video 15S — MVP V1

Đây là bộ khung sản phẩm đầu tiên cho website “Nhập 1 câu → tạo video 10–20 giây”.

## Chạy local

```bash
npm install
npm run dev
```

Mở `http://localhost:3000`.

## Hiện trạng

- Landing page hoạt động.
- Form tạo video hoạt động.
- Template selection hoạt động.
- API tạo job + trạng thái video hoạt động.
- AI provider abstraction đã có.
- Mock AI tạo script JSON.
- Remotion composition mẫu đã có.
- SQL schema + RLS cho Supabase đã có.

## Việc cần nối trước khi production

1. Tạo Supabase project và chạy `sql/001_init.sql`.
2. Thay store in-memory bằng Supabase.
3. Thêm auth/middleware.
4. Nối AI text provider.
5. Nối TTS provider.
6. Nối image/video provider.
7. Render Remotion trên worker/server.
8. Upload MP4 lên Supabase Storage hoặc object storage.
9. Thêm queue bền vững (Redis/BullMQ hoặc dịch vụ queue).
10. Thêm billing/credits server-side.
11. Thêm rate limit, monitoring và logging.

## Kiến trúc

Next.js → API → Queue → AI providers → Remotion → Storage → User

Không đưa API keys vào client.
