'use client';
import {useState} from 'react';
import {useRouter} from 'next/navigation';

const templates=[['viral','🔥 Viral'],['top-list','📋 Top List'],['product','🛍️ Product'],['story','🎬 Story'],['quote','✨ Quote']];

export default function Home(){
 const [prompt,setPrompt]=useState(''); const [template,setTemplate]=useState('viral'); const router=useRouter();
 async function create(){ if(!prompt.trim()) return alert('Hãy nhập ý tưởng video.'); const r=await fetch('/api/videos',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt,template,duration:15,voice:'female-vn',subtitle:'tiktok'})}); const d=await r.json(); if(!r.ok)return alert(d.error||'Có lỗi'); router.push('/create?video='+d.video_id); }
 return <><header className="nav"><div className="logo">AI VIDEO 15S</div><button className="btn secondary" onClick={()=>router.push('/create')}>Dashboard</button></header><main className="container"><section className="hero"><div className="tag">AI SHORT VIDEO MAKER</div><h1>Nhập 1 câu.<br/>Nhận 1 video 15 giây.</h1><p>Không cần biết edit. Không cần biết prompt. Biến ý tưởng thành video dọc cho TikTok, Reels và Shorts.</p><div className="create card"><div className="field"><textarea rows={4} value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Ví dụ: 3 công cụ AI dân văn phòng nên biết..."/></div><div className="field"><label>Chọn phong cách</label><div className="templates">{templates.map(([id,name])=><button key={id} className={'card template '+(template===id?'active':'')} onClick={()=>setTemplate(id)}>{name}</button>)}</div></div><button className="btn" onClick={create}>✨ Tạo video miễn phí</button></div></section></main></>;
}
