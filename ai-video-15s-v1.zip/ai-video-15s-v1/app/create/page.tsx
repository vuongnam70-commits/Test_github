'use client';
import {useEffect,useState} from 'react';
import {useSearchParams} from 'next/navigation';

export default function Create(){
 const params=useSearchParams(); const id=params.get('video'); const [data,setData]=useState<any>(null);
 useEffect(()=>{ if(!id)return; let timer:any; const poll=async()=>{const r=await fetch('/api/videos/'+id);const d=await r.json();setData(d);if(!['completed','failed'].includes(d.status))timer=setTimeout(poll,1500)};poll();return()=>clearTimeout(timer)},[id]);
 if(!id)return <main className="container"><h1>Tạo video</h1><p className="muted">Quay lại trang chủ để bắt đầu.</p></main>;
 return <main className="container"><h1>Video của bạn</h1><div className="status">Trạng thái: <b>{data?.status||'queued'}</b></div>{data?.status==='completed'&&data.video_url?<div><div className="videoBox"><video src={data.video_url} controls playsInline/></div><p><a className="btn" href={data.video_url} download>Tải video</a></p></div>:<div className="card"><h2>🎬 Đang tạo video...</h2><p className="muted">{data?.stage||'Đang xử lý'}</p><p className="muted">Bạn có thể giữ trang này mở; hệ thống sẽ tự cập nhật.</p></div>}{data?.status==='failed'&&<div className="card">Không thể tạo video: {data.error_message||'Lỗi không xác định'}</div>}</main>;
}
