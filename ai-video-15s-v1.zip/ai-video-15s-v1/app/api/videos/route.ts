import {NextResponse} from 'next/server';
import {z} from 'zod';
import {randomUUID} from 'crypto';
import {videos} from '@/lib/db/store';
import {processVideo} from '@/lib/video/render';

const schema=z.object({prompt:z.string().min(3).max(1000),template:z.string(),duration:z.union([z.literal(10),z.literal(15),z.literal(20)]).default(15),voice:z.string().optional(),subtitle:z.string().optional()});
export async function POST(req:Request){try{const body=schema.parse(await req.json());const id=randomUUID();videos.set(id,{id,...body,status:'queued'});void processVideo(id);return NextResponse.json({video_id:id,status:'queued'});}catch(e){return NextResponse.json({error:e instanceof z.ZodError?e.issues:'Invalid request'},{status:400});}}
