import {NextResponse} from 'next/server';
import {videos} from '@/lib/db/store';
import {processVideo} from '@/lib/video/render';
export async function POST(_:Request,{params}:{params:Promise<{id:string}>}){const {id}=await params;const v=videos.get(id);if(!v)return NextResponse.json({error:'Not found'},{status:404});v.status='queued';v.video_url=undefined;void processVideo(id);return NextResponse.json({video_id:id,status:'queued'});}
