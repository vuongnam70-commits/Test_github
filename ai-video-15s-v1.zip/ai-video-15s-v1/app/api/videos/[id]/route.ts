import {NextResponse} from 'next/server';
import {videos} from '@/lib/db/store';
export async function GET(_:Request,{params}:{params:Promise<{id:string}>}){const {id}=await params;const v=videos.get(id);if(!v)return NextResponse.json({error:'Not found'},{status:404});return NextResponse.json(v);}
