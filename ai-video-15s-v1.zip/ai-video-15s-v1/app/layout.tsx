import './globals.css';
import React from 'react';

export const metadata = { title: 'AI Video 15S', description: 'Nhập một câu, tạo video ngắn bằng AI.' };

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="vi"><body>{children}</body></html>;
}
